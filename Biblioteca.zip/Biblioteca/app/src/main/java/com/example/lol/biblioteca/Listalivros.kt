package com.example.lol.biblioteca

//DATA CLASS PARA O RV DOS LIVROS

data class Listalivros(var capa: Int,var titulo :String, var autor: String, var editora: String, var anoPublicacao: String) {
}